#!/bin/sh

./eclipse/eclipse -data workspace
