from original_hal import Hal
from speech_recognition_module import SpeechRecognitionModule
from face_recognition_module import FaceRecognitionModule
from blockly_methods import BlocklyMethods

__version__ = "1.0.0"
