package org.mariadb.jdbc.internal.util;

public interface PidRequestInter {
    String getPid();
}
