package com.example.ktws.util;

public enum  Day {
    MON, TUE, WED, THU, FRI, SAT, SUN
}
