package com.example.ktws.util;

public enum TypeOfFace {
    ALL
}
