# 课堂威视 [![Build Status](https://travis-ci.org/Atorios/SE230-Summer.svg?branch=dev)](https://travis-ci.org/Atorios/SE230-Summer)
## 第三组
- 黎君（组长）
- 黄友奇
- 何荣俊
- 胡嘉弘
