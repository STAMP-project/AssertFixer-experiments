# StudyVariable

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**assay_refs** | [**list[Assay]**](Assay.md) |  | [optional] 
**sample_refs** | [**list[Sample]**](Sample.md) |  | [optional] 
**average_function** | [**Parameter**](Parameter.md) |  | [optional] 
**variation_function** | [**Parameter**](Parameter.md) |  | [optional] 
**description** | **str** |  | [optional] 
**factors** | [**list[Parameter]**](Parameter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


