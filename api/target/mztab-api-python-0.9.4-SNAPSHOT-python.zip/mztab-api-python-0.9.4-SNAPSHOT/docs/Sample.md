# Sample

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | [optional] 
**custom** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**id_confidence_measure** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**species** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**tissue** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**cell_type** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**disease** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


