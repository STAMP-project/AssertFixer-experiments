# Instrument

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**instrument_name** | [**Parameter**](Parameter.md) |  | [optional] 
**instrument_source** | [**Parameter**](Parameter.md) |  | [optional] 
**instrument_analyzer** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**instrument_detector** | [**Parameter**](Parameter.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


