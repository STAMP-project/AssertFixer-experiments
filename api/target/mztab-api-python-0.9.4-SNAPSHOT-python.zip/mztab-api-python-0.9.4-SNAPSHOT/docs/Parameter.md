# Parameter

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**cv_label** | **str** |  | [optional] [default to '']
**cv_accession** | **str** |  | [optional] [default to '']
**name** | **str** |  | 
**value** | **str** |  | [default to '']

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


