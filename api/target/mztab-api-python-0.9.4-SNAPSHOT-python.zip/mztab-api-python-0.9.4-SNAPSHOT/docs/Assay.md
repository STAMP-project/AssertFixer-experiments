# Assay

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**name** | **str** |  | 
**custom** | [**list[Parameter]**](Parameter.md) |  | [optional] 
**external_uri** | **str** |  | [optional] 
**sample_ref** | [**Sample**](Sample.md) |  | 
**ms_run_ref** | [**MsRun**](MsRun.md) |  | 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


