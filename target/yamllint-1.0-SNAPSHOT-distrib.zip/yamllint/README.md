YAML Lint
=========

YAML lint written in Java.
It's main purpose is to provide an API and scripts to analyze YAML documents.

[![Build Status](https://travis-ci.org/sbaudoin/yamllint.svg?branch=master)](https://travis-ci.org/sbaudoin/yamllint)

## API usage
See JavaDoc

## Batch tool
Get the `.zip` or `.tar.gz` distribution archive, unpack and execute the script corresponding to your platform in the `bin` directory:

    bin/yamllint ...

or

    bin\yamllint ...
